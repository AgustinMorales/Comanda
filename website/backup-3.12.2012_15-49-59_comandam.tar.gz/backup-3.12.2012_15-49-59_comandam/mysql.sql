-- cPanel mysql backup
GRANT USAGE ON *.* TO 'comandam'@'localhost' IDENTIFIED BY PASSWORD '*A4A0AF6710D06A0DB87D7399A78816902F2C6F38';
GRANT ALL PRIVILEGES ON `comandam\_basedatos\_joomla`.* TO 'comandam'@'localhost';
GRANT ALL PRIVILEGES ON `comandam\_%`.* TO 'comandam'@'localhost';
GRANT USAGE ON *.* TO 'comandam_joomla'@'localhost' IDENTIFIED BY PASSWORD '*B10263695F5ACF403AC28A6AC8F6ADFE0B9DCFF5';
GRANT ALL PRIVILEGES ON `comandam\_basedatos\_joomla`.* TO 'comandam_joomla'@'localhost';
